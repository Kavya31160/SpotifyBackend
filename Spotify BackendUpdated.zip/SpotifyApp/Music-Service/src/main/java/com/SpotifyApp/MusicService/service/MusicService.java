package com.SpotifyApp.MusicService.service;

import java.util.List;

import com.SpotifyApp.MusicService.Entity.Recommendation;
import com.SpotifyApp.MusicService.Entity.RecommendationResponse;

public interface MusicService {
	
	public List<Recommendation>  getMusic();
	

}
