/*
 * package com.SpotifyApp.MusicService.Test.controller;
 * 
 * import static org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.junit.jupiter.api.Assertions.assertNull; import static
 * org.mockito.Mockito.times; import static org.mockito.Mockito.verify; import
 * static org.mockito.Mockito.when;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import org.springframework.http.HttpStatus;
 * import org.springframework.http.ResponseEntity;
 * 
 * import com.SpotifyApp.MusicService.Entity.Recommendation; import
 * com.SpotifyApp.MusicService.controller.MusicController; import
 * com.SpotifyApp.MusicService.service.MusicService;
 * 
 * import jakarta.servlet.ServletException; import
 * jakarta.ws.rs.InternalServerErrorException;
 * 
 * public class MusicControllerTest {
 * 
 * @Mock private MusicService musicService;
 * 
 * @InjectMocks private MusicController musicController;
 * 
 * @BeforeEach void setUp() { MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void getAllMusicTest_MusicExists() { // Given Recommendation
 * recommendation = new Recommendation();
 * recommendation.setId("jkhfjkdhkaadjjdK");
 * recommendation.setLabel("jdsajajdh");
 * 
 * when(musicService.getMusic()).thenReturn(recommendation);
 * 
 * 
 * ResponseEntity<Recommendation> response = musicController.getAllMusic();
 * 
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals(recommendation, response.getBody()); verify(musicService,
 * times(1)).getMusic(); }
 * 
 * @Test public void getAllMusicTest_NoMusic() {
 * 
 * when(musicService.getMusic()).thenReturn(null);
 * 
 * 
 * ResponseEntity<Recommendation> response = musicController.getAllMusic();
 * 
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertNull(response.getBody()); verify(musicService, times(1)).getMusic(); }
 * 
 * 
 * 
 * 
 * }
 * 
 */