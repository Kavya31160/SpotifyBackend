package com.SpotifyApp.wishlist.WishlistService.repository;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;

@Repository
public interface UserWishlistRepo extends CrudRepository<UserWishlist,Long >{

	//create repo

}
