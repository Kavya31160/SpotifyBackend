package com.SpotifyAuth.AuthService.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.KafkaTemplate;

import com.SpotifyAuth.AuthService.model.UserInfo;
import com.SpotifyAuth.AuthService.repo.UserRepo;
import com.SpotifyAuth.AuthService.service.UserServiceImpl;
import com.google.gson.Gson;

@Configuration
@EnableKafka
public class KafkaConfigConsumer {

	@Autowired
	Gson gson;
	
	@Autowired
	UserServiceImpl authUserService;

	@KafkaListener(topics = "user-register", groupId="group-id")
	public void consume(String users) {
		System.out.println("received message=" +users);
		UserInfo userdata = gson.fromJson(users, UserInfo.class);
		UserInfo result = authUserService.registerUser(userdata);

		System.out.println("Stored data in User Copy" + userdata.toString());
		
		
	}
	
}
