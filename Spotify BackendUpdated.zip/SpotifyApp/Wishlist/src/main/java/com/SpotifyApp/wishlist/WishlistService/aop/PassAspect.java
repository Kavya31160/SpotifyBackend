package com.SpotifyApp.wishlist.WishlistService.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class PassAspect {

	Logger mylog = LoggerFactory.getLogger(PassAspect.class);

	@Before("execution (* com.SpotifyApp.wishlist.WishlistService.controller.UserWishlistController.addTrack(..))")
	public void beforeadd(JoinPoint jp) {
		mylog.info("Some User is calling addTrack method" + jp.toString());
	}
	
	  
	  @Before("execution (* com.SpotifyApp.wishlist.WishlistService.controller.UserWishlistController.removeTrack(..))"
	  ) public void beforeRemove(JoinPoint jp) {
	  mylog.info("Some User is calling removeTrack method" + jp.toString()); }
	  
	  @Before("execution (* com.SpotifyApp.wishlist.WishlistService.controller.UserWishlistController.getTrack(..))"
			  ) public void beforeGet(JoinPoint jp) {
			  mylog.info("Some User is calling removeTrack method" + jp.toString()); }
	  
	  
	 

}
