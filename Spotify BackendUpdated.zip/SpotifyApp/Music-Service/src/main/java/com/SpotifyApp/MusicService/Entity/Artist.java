package com.SpotifyApp.MusicService.Entity;

import lombok.Data;

@Data
public class Artist {
 private String href;
 private String id;
 private String name;


 
}
