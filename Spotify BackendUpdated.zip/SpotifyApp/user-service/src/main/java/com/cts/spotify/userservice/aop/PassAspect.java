package com.cts.spotify.userservice.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class PassAspect {
	Logger mylog = LoggerFactory.getLogger(PassAspect.class);

	@Before("execution (* com.cts.spotify.userservice.controller.UserController.saveUser(..))")
	public void beforeSaveUser(JoinPoint jp) {
		mylog.info("Some Client is calling saveUser method" + jp.toString());
	}
	
	
	@Before("execution (* com.cts.spotify.userservice.controller.UserController.updateUser(..))")
	public void beforeupdateUser(JoinPoint jp) {
		mylog.info("Some Client is calling updateUser method" + jp.toString());
	}
	
	
	@Before("execution (* com.cts.spotify.userservice.controller.UserController.deleteUser(..))")
	public void beforeupdatedeleteUser(JoinPoint jp) {
		mylog.info("Some Client is calling deleteUser method" + jp.toString());
	}
	
	@Before("execution (* com.cts.spotify.userservice.controller.UserController.findUserByUseremail(..))")
	public void beforeupdatefindUserByUseremail(JoinPoint jp) {
		mylog.info("Some Client is calling findUserByUseremail method" + jp.toString());
	}
}
