package com.SpotifyApp.wishlist.WishlistService.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;
import com.SpotifyApp.wishlist.WishlistService.exception.UserNotFoundException;
import com.SpotifyApp.wishlist.WishlistService.repository.UserWishlistRepo;

@Service
public class UserWishlistServiceImpl implements UserWishlistService {
	private final UserWishlistRepo userWishlistRepo;

	@Autowired
	public UserWishlistServiceImpl(UserWishlistRepo userWishlistRepo) {
		this.userWishlistRepo = userWishlistRepo;
	}

	@Override
	public UserWishlist addTrack(UserWishlist wishlist) {
		Optional<UserWishlist> wishlistEntity = userWishlistRepo.findByUserId(wishlist.getUserId());
		if (wishlistEntity.isPresent()) {
			wishlistEntity.get().getTracks().addAll(wishlist.getTracks());
			userWishlistRepo.save(wishlistEntity.get());
			return wishlistEntity.get();
		} else {
			return userWishlistRepo.save(wishlist);
		}
	}

	@Override
	public UserWishlist findByUserId(Long userId) {

		Optional<UserWishlist> wishlist1 = userWishlistRepo.findByUserId(userId);
		if (wishlist1.isPresent()) {
			return wishlist1.get();
		} else {
			throw new UserNotFoundException("Did not find Track");
		}
	}

	@Override
	public void removeTrack(Long wishlistId, String trackId) {
		Optional<UserWishlist> wishlistEntity = userWishlistRepo.findById(wishlistId);
		if (wishlistEntity.isPresent()) {
			wishlistEntity.get().getTracks().removeIf(t -> t.getTrackId().equalsIgnoreCase(trackId));
		} else {
			throw new UserNotFoundException("No wishlist present with id " + wishlistId);
		}
		userWishlistRepo.save(wishlistEntity.get());
         
	}

}