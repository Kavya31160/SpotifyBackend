package com.SpotifyApp.MusicService.Entity;

import java.util.List;

import lombok.Data;

@Data
public class RecommendationResponse {
	
	private List <Recommendation> tracks;

}
