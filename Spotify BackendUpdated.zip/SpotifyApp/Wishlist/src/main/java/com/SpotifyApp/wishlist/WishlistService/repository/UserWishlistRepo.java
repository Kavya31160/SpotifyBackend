package com.SpotifyApp.wishlist.WishlistService.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;

public interface UserWishlistRepo extends JpaRepository<UserWishlist, Long> {
	Optional<UserWishlist> findByUserId(long id);
}
