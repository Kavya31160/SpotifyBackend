package com.SpotifyAuth.AuthService.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class PassAspect {

	Logger mylog = LoggerFactory.getLogger(PassAspect.class);

	@Before("execution (* com.SpotifyAuth.AuthService.controller.AuthController.login(..))")
	public void beforeadd(JoinPoint jp) {
		mylog.info("Some logined " + jp.toString());
	}
	
	  
	  @Before("execution (* com.SpotifyAuth.AuthService.config.KafkaConfigConsumer.consume(..))"
	  ) public void beforeConsume(JoinPoint jp) {
	  mylog.info("Some User is regesting via kafak consume method" + jp.toString()); }
	  
	
	  
	  
	 

}
