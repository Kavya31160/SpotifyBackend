package com.SpotifyAuth.AuthService.service;

import com.SpotifyAuth.AuthService.model.UserInfo;

public interface UserService {
	// String getUserId(String email, String password);
	UserInfo login(String email, String password);

}
