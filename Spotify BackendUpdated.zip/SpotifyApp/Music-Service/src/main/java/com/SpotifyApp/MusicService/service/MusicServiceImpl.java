package com.SpotifyApp.MusicService.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.SpotifyApp.MusicService.Entity.Recommendation;
import com.SpotifyApp.MusicService.Entity.RecommendationResponse;
import com.SpotifyApp.MusicService.Entity.Token;
import com.SpotifyApp.MusicService.controller.MusicController;

@Service
public class MusicServiceImpl implements MusicService {

	private static final Logger logger = LoggerFactory.getLogger(MusicServiceImpl.class);
	RestTemplate restTemplate = new RestTemplate();

	@Value("${url.spotify.token}")
	private String tokenUrl;

	@Value("${url.spotify.recommendation}")
	private String albumUrl;

	public Token getToken() {
		logger.info("Executing get token");
		// String url =
		// "https://accounts.spotify.com/api/token?grant_type=client_credentials&client_id=f6341db94a86455796ac8019e813b017&client_secret=fd892f353b064f0ab0542ef7da8dcdb1";

		ResponseEntity<Token> token = restTemplate.exchange(tokenUrl, HttpMethod.POST, getsEntity(), Token.class);
		logger.info("token retrived");
		return token.getBody();
	}

	public List<Recommendation> getMusic() {

		// String url = "https://api.spotify.com/v1/albums/0sNOF9WDwhWunNAHPD3Baj";

		ResponseEntity<RecommendationResponse> details = restTemplate.exchange(albumUrl, HttpMethod.GET, getEntity(),
				RecommendationResponse.class);

		return  details.getBody().getTracks();
	}

	private HttpEntity getEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		Token token = getToken();
		headers.setBearerAuth(token.getAccess_token());
		return new HttpEntity<>(headers);
	}

	private HttpEntity getsEntity() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", "application/json");
		return new HttpEntity<>(headers);

	}
}
