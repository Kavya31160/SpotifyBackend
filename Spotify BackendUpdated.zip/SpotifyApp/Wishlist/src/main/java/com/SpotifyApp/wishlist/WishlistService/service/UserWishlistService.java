package com.SpotifyApp.wishlist.WishlistService.service;


import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;


public interface UserWishlistService {
	
	UserWishlist addTrack(UserWishlist wishlist);	
	void  removeTrack(Long id, String trackId);
	UserWishlist findByUserId(Long id);
	


}
