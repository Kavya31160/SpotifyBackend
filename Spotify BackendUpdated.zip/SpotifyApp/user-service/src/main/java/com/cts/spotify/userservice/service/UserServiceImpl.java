package com.cts.spotify.userservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.cts.spotify.userservice.entity.User;
import com.cts.spotify.userservice.exception.UserAlreadyExistsException;
import com.cts.spotify.userservice.exception.UserNotFoundException;
import com.cts.spotify.userservice.kafka.KafkaConfig;
import com.cts.spotify.userservice.repository.UserRepo;
import com.google.gson.Gson;

@Service
public class UserServiceImpl implements UserService {
	// private static final Logger logger =
	// LoggerFactory.getLogger(UserServiceImpl.class);

	@Autowired
	KafkaTemplate<String, String> kafkaTemplate;

	@Autowired
	private Gson gson;

	private UserRepo userRepo;
	private static final String TOPIC = "user-register";

	@Autowired
	public UserServiceImpl(UserRepo userRepo) {
		this.userRepo = userRepo;
	}

	@Override
	public User saveUser(User user) {
		// logger.info(" Executing Save User");
		Optional<User> user1 = userRepo.findById(user.getId());
		if (user1.isPresent()) {
			throw new UserAlreadyExistsException("User Already Exists");
		} else {
			User userres=userRepo.save(user);
			 
			kafkaTemplate.send(TOPIC, gson.toJson(userres));
			
			return userres;
		}

	}

	@Override
	public User updateUser(User user) {
		// logger.info(" Executing UdatUser");
		Optional<User> user1 = userRepo.findById(user.getId());
		if (user1.isPresent()) {
			User tempuser = user1.get();
			tempuser.setFirstname(user.getFirstname());
			tempuser.setLastname(user.getLastname());
			tempuser.setUseremail(user.getUseremail());
			tempuser.setPassword(user.getPassword());
			return userRepo.save(tempuser);
		} else {
			throw new UserNotFoundException("User not Found");
		}
	}

	@Override
	public User deleteUser(Long id) {
		// logger.info(" Executing deleteUser");
		Optional<User> user1 = userRepo.findById(id);
		if (user1.isPresent()) {
			userRepo.deleteById(id);
			return user1.get();
		} else {
			throw new UserNotFoundException("User not found");
		}
	}

	@Override
	public User findByUseremail(String useremail) {
		// logger.info(" Executing getUser");
		return userRepo.findByUseremail(useremail);
	}

}
