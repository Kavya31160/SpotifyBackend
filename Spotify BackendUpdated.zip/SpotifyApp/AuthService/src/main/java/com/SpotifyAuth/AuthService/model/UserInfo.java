package com.SpotifyAuth.AuthService.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "Users")
public class UserInfo {
	private String id;

	@Id
	private String useremail;

	private String password;

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public UserInfo(String useremail, String password) {
		super();
		this.useremail = useremail;
		this.password = password;
	}

	public UserInfo() {
		super();
	}

	/*
	 * @Override public String toString() { return "UserInfo{" + "useremail='"
	 * +useremail + '\''+",password='" + password + '\''+'}'; }
	 */
}
