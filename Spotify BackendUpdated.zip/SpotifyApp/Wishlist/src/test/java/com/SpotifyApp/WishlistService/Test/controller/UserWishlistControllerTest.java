package com.SpotifyApp.WishlistService.Test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;
import com.SpotifyApp.wishlist.WishlistService.controller.UserWishlistController;
import com.SpotifyApp.wishlist.WishlistService.service.UserWishlistService;

//public class UserWishlistControllerTest {
//
//	  @Mock
//	    private UserWishlistService wishlistService;
//	 
//	    @InjectMocks
//	    private UserWishlistController wishlistController;
//	 
//	    @BeforeEach
//	    void setUp() {
//	        MockitoAnnotations.initMocks(this);
//	    }
//	    @Test
//	    public void addTrackTest() {
//	        // Given
//	        UserWishlist wishlistToAdd = new UserWishlist();
//	        wishlistToAdd.setHref("http://spotify.com");
//	        wishlistToAdd.setTrackId("dnhjasdhjbvcj");
//	        wishlistToAdd.setTrackName("cyndi loper");
//	        wishlistToAdd.setWishlistId(1);
//	        
//	        when(wishlistService.addTrack(wishlistToAdd)).thenReturn(wishlistToAdd);
//	 
//	        // When
//	        ResponseEntity<UserWishlist> response = wishlistController.addTrack(wishlistToAdd);
//	 
//	        // Then
//	        assertEquals(HttpStatus.CREATED, response.getStatusCode());
//	        assertEquals(wishlistToAdd, response.getBody());
//	        verify(wishlistService, times(1)).addTrack(wishlistToAdd);
//	    }
//	 
//	    @Test
//	    public void removeTrackTest() {
//	        // Given
//	        Long wishlistIdToRemove = 1L;
//	        when(wishlistService.removeTrack(wishlistIdToRemove)).thenReturn("Track removed successfully");
//	 
//	        // When
//	        ResponseEntity<String> response = wishlistController.removeTrack(wishlistIdToRemove);
//	 
//	        // Then
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//	        assertEquals("Track removed successfully", response.getBody());
//	        verify(wishlistService, times(1)).removeTrack(wishlistIdToRemove);
//	    }
//	 
//	    @Test
//	    public void getTrackTest() {
//	        // Given
//	        Long wishlistIdToGet = 1L;
//	        UserWishlist wishlist = new UserWishlist();
//	        when(wishlistService.findByWishlistId(wishlistIdToGet)).thenReturn(wishlist);
//	 
//	        // When
//	        ResponseEntity<UserWishlist> response = wishlistController.getTrack(wishlistIdToGet);
//	 
//	        // Then
//	        assertEquals(HttpStatus.OK, response.getStatusCode());
//	        assertEquals(wishlist, response.getBody());
//	        verify(wishlistService, times(1)).findByWishlistId(wishlistIdToGet);
//	    }
//}
