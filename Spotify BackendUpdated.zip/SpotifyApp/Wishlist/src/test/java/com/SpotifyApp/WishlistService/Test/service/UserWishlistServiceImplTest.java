//package com.SpotifyApp.WishlistService.Test.service;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.util.Optional;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//
//import com.SpotifyApp.wishlist.WishlistService.Entity.UserWishlist;
//import com.SpotifyApp.wishlist.WishlistService.exception.UserNotFoundException;
//import com.SpotifyApp.wishlist.WishlistService.repository.UserWishlistRepo;
//import com.SpotifyApp.wishlist.WishlistService.service.UserWishlistServiceImpl;
//
//public class UserWishlistServiceImplTest {
//	  @Mock
//	    private UserWishlistRepo userWishlistRepo;
//	 
//	    @InjectMocks
//	    private UserWishlistServiceImpl userWishlistService;
//	 
//
//	    @BeforeEach
//	    void setUp() {
//	        MockitoAnnotations.initMocks(this);
//	    }
//	    @Test
//	    public void addTrackTest() {
//	        // Given
//	        UserWishlist wishlistToAdd = new UserWishlist();
//	        when(userWishlistRepo.save(wishlistToAdd)).thenReturn(wishlistToAdd);
//	 
//	        // When
//	        UserWishlist addedWishlist = userWishlistService.addTrack(wishlistToAdd);
//	 
//	        // Then
//	        assertEquals(wishlistToAdd, addedWishlist);
//	        verify(userWishlistRepo, times(1)).save(wishlistToAdd);
//	    }
//	 
//	    @Test
//	    public void findByWishlistIdTest_WishlistExists() {
//	        // Given
//	        Long wishlistIdToFind = 1L;
//	        UserWishlist wishlist = new UserWishlist();
//	        when(userWishlistRepo.findById(wishlistIdToFind)).thenReturn(Optional.of(wishlist));
//	 
//	        // When
//	        UserWishlist foundWishlist = userWishlistService.findByWishlistId(wishlistIdToFind);
//	 
//	        // Then
//	        assertEquals(wishlist, foundWishlist);
//	        verify(userWishlistRepo, times(1)).findById(wishlistIdToFind);
//	    }
//	 
//	    @Test
//	    public void findByWishlistIdTest_WishlistNotExists() {
//	        // Given
//	        Long wishlistIdToFind = 1L;
//	        when(userWishlistRepo.findById(wishlistIdToFind)).thenReturn(Optional.empty());
//	 
//	        // When / Then
//	        assertThrows(UserNotFoundException.class, () -> userWishlistService.findByWishlistId(wishlistIdToFind));
//	        verify(userWishlistRepo, times(1)).findById(wishlistIdToFind);
//	    }
//	 
//	    @Test
//	    public void removeTrackTest() {
//	        // Given
//	        Long wishlistIdToRemove = 1L;
//	 
//	        // When
//	        String result = userWishlistService.removeTrack(wishlistIdToRemove);
//	 
//	        // Then
//	        assertEquals("removed track", result);
//	        verify(userWishlistRepo, times(1)).deleteById(wishlistIdToRemove);
//	    }
//	 
//	    // Add more test cases as needed to cover different scenarios
//	}
//
//
