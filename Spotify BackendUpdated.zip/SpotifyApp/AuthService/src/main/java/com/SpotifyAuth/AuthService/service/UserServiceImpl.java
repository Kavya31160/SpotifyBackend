package com.SpotifyAuth.AuthService.service;

import java.util.Optional;

import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.stereotype.Service;

import com.SpotifyAuth.AuthService.model.UserInfo;
import com.SpotifyAuth.AuthService.repo.UserRepo;

@Service

public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepo repo;

	@Override
	public UserInfo login(String email, String password) {

		Optional<UserInfo> userinfo = repo.findByUseremailAndPassword(email, password);
		if (userinfo.isPresent()) {

			return userinfo.get();
		} else {
			return null;
		}
	}

	public UserInfo registerUser(UserInfo userdata) {
		Optional<UserInfo> userinfo = repo.findById(userdata.getUseremail());
		if (userinfo.isEmpty()) {
			return repo.save(userdata);

		} else
			return null;
	}

}
